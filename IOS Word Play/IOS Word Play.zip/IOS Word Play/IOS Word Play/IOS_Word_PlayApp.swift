//
//  IOS_Word_PlayApp.swift
//  IOS Word Play
//
//  Created by Student on 10/6/21.
//

import SwiftUI

@main
struct IOS_Word_PlayApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
